package vttp.ssf.assessment.eventmanagement.services;

public class DatabaseService {
    
    // TODO: Task 1
}
