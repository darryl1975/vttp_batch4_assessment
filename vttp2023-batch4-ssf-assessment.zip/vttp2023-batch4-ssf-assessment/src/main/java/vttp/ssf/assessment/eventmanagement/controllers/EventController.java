package vttp.ssf.assessment.eventmanagement.controllers;

public class EventController {

	//TODO: Task 5


}
