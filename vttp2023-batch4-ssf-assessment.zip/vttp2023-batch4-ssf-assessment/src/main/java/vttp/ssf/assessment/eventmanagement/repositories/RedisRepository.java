package vttp.ssf.assessment.eventmanagement.repositories;

public class RedisRepository {

	// TODO: Task 2


	// TODO: Task 3


	// TODO: Task 4
}
